غرفتي 3D - مشروع Android
========================
هذه نسخة Android قابلة للبناء، وتحتوي على واجهة غرفتي 3D الحالية داخل WebView.
لفتحها: Android Studio > Open > اختر مجلد Ghurfati3D > Build APK.

ملاحظة: هذا الملف مشروع Android وليس APK جاهزاً. بناء APK يحتاج Android Studio/بيئة Gradle.
